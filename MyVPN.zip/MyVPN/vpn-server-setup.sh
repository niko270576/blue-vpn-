#!/usr/bin/env bash
# =====================================================================
#  MyVPN - Server setup (WireGuard)
#  Trexei se Ubuntu/Debian VPS (p.x. Hetzner, DigitalOcean, Vultr).
#
#  Egkatastasi server:     sudo bash vpn-server-setup.sh install
#  Neos xristis/syskevi:   sudo bash vpn-server-setup.sh add-client onoma
#  Lista xriston:          sudo bash vpn-server-setup.sh list
#  Diagrafi xristi:        sudo bash vpn-server-setup.sh remove-client onoma
# =====================================================================
set -euo pipefail

WG_DIR=/etc/wireguard
WG_IF=wg0
WG_PORT=51820
SUBNET=10.8.0
CLIENT_DIR=/root/myvpn-clients
DNS="1.1.1.1, 9.9.9.9"

die() { echo "ERROR: $*" >&2; exit 1; }
[[ $EUID -eq 0 ]] || die "Trexe to me sudo."

public_ip() {
  curl -4 -s --max-time 5 https://api.ipify.org || hostname -I | awk '{print $1}'
}

install_server() {
  [[ -f $WG_DIR/$WG_IF.conf ]] && die "O server einai idi egkatestimenos."
  echo "[*] Egkatastasi paketon..."
  apt-get update -y
  apt-get install -y wireguard iptables qrencode curl

  echo "[*] Energopoiisi IP forwarding..."
  echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/99-myvpn.conf
  sysctl --system >/dev/null

  local nic
  nic=$(ip -4 route show default | awk '{print $5; exit}')
  [[ -n $nic ]] || die "Den vrethike network interface."

  umask 077
  mkdir -p "$WG_DIR" "$CLIENT_DIR"
  wg genkey | tee $WG_DIR/server.key | wg pubkey > $WG_DIR/server.pub

  cat > $WG_DIR/$WG_IF.conf <<EOF
[Interface]
Address = $SUBNET.1/24
ListenPort = $WG_PORT
PrivateKey = $(cat $WG_DIR/server.key)
PostUp   = iptables -A FORWARD -i $WG_IF -j ACCEPT; iptables -A FORWARD -o $WG_IF -j ACCEPT; iptables -t nat -A POSTROUTING -o $nic -j MASQUERADE
PostDown = iptables -D FORWARD -i $WG_IF -j ACCEPT; iptables -D FORWARD -o $WG_IF -j ACCEPT; iptables -t nat -D POSTROUTING -o $nic -j MASQUERADE
EOF

  # Anoigma firewall an yparxei ufw
  if command -v ufw >/dev/null && ufw status | grep -q active; then
    ufw allow $WG_PORT/udp
  fi

  systemctl enable --now wg-quick@$WG_IF
  echo
  echo "[OK] O VPN server trexei sto $(public_ip):$WG_PORT/udp"
  echo "     Tora prosthese syskevi:  sudo bash $0 add-client laptop"
}

next_ip() {
  local used n
  used=$(grep -oP "AllowedIPs = $SUBNET\.\K[0-9]+" $WG_DIR/$WG_IF.conf || true)
  for n in $(seq 2 254); do
    grep -qx "$n" <<<"$used" || { echo "$n"; return; }
  done
  die "Den yparxoun eleftheres IP."
}

add_client() {
  local name=${1:-}
  [[ $name =~ ^[A-Za-z0-9_-]{1,20}$ ]] || die "Dose onoma (grammata/arithmoi, ews 20)."
  [[ -f $WG_DIR/$WG_IF.conf ]] || die "Trexe prota: install"
  grep -q "# client: $name\$" $WG_DIR/$WG_IF.conf && die "O xristis $name yparxei idi."

  umask 077
  local priv pub psk ip conf
  priv=$(wg genkey); pub=$(echo "$priv" | wg pubkey); psk=$(wg genpsk)
  ip=$SUBNET.$(next_ip)

  cat >> $WG_DIR/$WG_IF.conf <<EOF

# client: $name
[Peer]
PublicKey = $pub
PresharedKey = $psk
AllowedIPs = $ip/32
EOF
  wg set $WG_IF peer "$pub" preshared-key <(echo "$psk") allowed-ips "$ip/32"

  conf=$CLIENT_DIR/$name.conf
  cat > "$conf" <<EOF
[Interface]
PrivateKey = $priv
Address = $ip/32
DNS = $DNS

[Peer]
PublicKey = $(cat $WG_DIR/server.pub)
PresharedKey = $psk
Endpoint = $(public_ip):$WG_PORT
AllowedIPs = 0.0.0.0/0
PersistentKeepalive = 25
EOF

  echo "[OK] Dimiourgithike: $conf"
  echo "     Antegrapse to ston fakelo 'servers/' tis efarmogis MyVPN."
  echo "     Gia kinito (efarmogi WireGuard), skanare to QR:"
  qrencode -t ansiutf8 < "$conf"
}

list_clients() {
  grep -oP "# client: \K.*" $WG_DIR/$WG_IF.conf || echo "(kanenas xristis)"
  echo; wg show $WG_IF
}

remove_client() {
  local name=${1:-} pub
  [[ -n $name ]] || die "Dose onoma."
  pub=$(awk -v n="# client: $name" '$0==n{f=1;next} f&&/PublicKey/{print $3;exit}' $WG_DIR/$WG_IF.conf)
  [[ -n $pub ]] || die "Den vrethike o $name."
  wg set $WG_IF peer "$pub" remove
  # Svinei to block "# client: name" + [Peer] + 3 grammes
  sed -i "/^# client: $name\$/,/^AllowedIPs/d" $WG_DIR/$WG_IF.conf
  sed -i '/^$/N;/^\n$/D' $WG_DIR/$WG_IF.conf
  rm -f "$CLIENT_DIR/$name.conf"
  echo "[OK] Diagrafike o $name."
}

case "${1:-}" in
  install)        install_server ;;
  add-client)     add_client "${2:-}" ;;
  list)           list_clients ;;
  remove-client)  remove_client "${2:-}" ;;
  *) echo "Xrisi: sudo bash $0 {install|add-client ONOMA|list|remove-client ONOMA}"; exit 1 ;;
esac
