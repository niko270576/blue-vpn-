# MyVPN

Diko sou VPN me WireGuard: **server** (se VPS) + **efarmogi** me lista servers kai koumpi Connect.

## 1. Stisimo server (mia fora ana xora/server)

1. Noikiase ena VPS me Ubuntu (Hetzner, DigitalOcean, Vultr ~4-5 €/mina). Dialekse tin xora pou theleis (p.x. Germania).
2. Syndesou me SSH kai trexe:
   ```bash
   sudo bash vpn-server-setup.sh install
   sudo bash vpn-server-setup.sh add-client laptop
   ```
3. Tha ftiaxtei to arxeio `/root/myvpn-clients/laptop.conf`. Katevase to sto PC sou:
   ```bash
   scp root@IP_TOU_SERVER:/root/myvpn-clients/laptop.conf ./servers/Germany.conf
   ```
   (To onoma tou arxeiou = to onoma pou fainetai stin efarmogi.)

Gia perissoteres xores, epanelave se allo VPS kai vale kai auto to .conf ston fakelo `servers/`.
Gia kinito: egkatestise tin episimi efarmogi WireGuard kai skanare to QR pou vgazei to `add-client`.

## 2. Efarmogi sto PC

1. Egkatestise **WireGuard**: https://www.wireguard.com/install/
2. Egkatestise **Python 3.10+** (sta Windows tsekare "Add to PATH").
3. Vale ta `.conf` ston fakelo `servers/` dipla sto `myvpn.py`.
4. Trexe me dikaiomata diaxeiristi:
   - **Windows:** anoikse cmd os Administrator -> `python myvpn.py`
   - **Linux/macOS:** `sudo python3 myvpn.py`
     (Linux: `sudo apt install wireguard-tools python3-tk resolvconf`; macOS: `brew install wireguard-tools`)

### Ftiaxe .exe (Windows, proaireitiko)
```bash
pip install pyinstaller
pyinstaller --onefile --windowed --uac-admin myvpn.py
```
To `dist/myvpn.exe` zitaei mono tou admin. Vale dipla tou ton fakelo `servers/`.

## Entoles server
| Entoli | Ti kanei |
|---|---|
| `install` | Stinei ton VPN server |
| `add-client ONOMA` | Neos xristis/syskevi (.conf + QR) |
| `list` | Lista xriston kai syndeseis |
| `remove-client ONOMA` | Diagrafi xristi |
